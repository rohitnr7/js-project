let s;
let b;
let score=0;
let offset = 0.05;
let balls=[];
function setup(){
    createCanvas(600,400);
    s=new Slider(200,350,150);
    b=new Ball(301,344,5);
    balls.push(b);


}


function draw(){
    background(0);
    if (frameCount % 200 == 0) {
        let index=floor(random(balls.length))
        let childs=floor(random(2,5))

        for(let i=0;i<childs;i++){
            let ball=new Ball(balls[index].x,balls[index].y,floor(random(2, 6)))
            balls.push(ball);
        }



    }
    score += offset * balls.length;
    // Printing the score. 
    textSize(24)
    fill(0, 255, 0)
    text("SCORE: " + nf(score, 1, 1), 10, 40)
    s.display();
    for(let i=balls.length-1;i>=0;i--){
        balls[i].display();
        let over=balls[i].update();
        if(over){
            balls.splice(i,1)


        }
        else{
            if(balls[i].hit(s)){
                balls[i].up=true;
            }

        }
       
    }
    if(balls.length==0){
        noLoop();
    }
    
    if (keyIsPressed) {
        if (keyCode == LEFT_ARROW) {
            s.moveLeft();
        } else if (keyCode == RIGHT_ARROW) {
            s.moveRight();
        }
    }
}


