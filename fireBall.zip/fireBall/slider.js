class Slider{
    constructor(x,y,w){
        this.x=x;
        this.y=y;
        this.w=w;
        this.h=5;
        this.s=7;

    }

    display(){
        fill(255, 255, 0);
        rect(this.x, this.y, this.w, this.h)

    }

    moveLeft(){
        this.x -=this.s;
        if(this.x <= 0)
            this.x=0;
    }

    moveRight(){
        this.x +=this.s;
        if(this.x >= width-this.w)
            this.x=width-this.w;
    }

    hit(b){
        if(b.x >= this.x && b.x <= this.x + this.w){
            if(b.y >= this.y - b.r/2){
                return true;
            }
        }
        return false;


    }

}