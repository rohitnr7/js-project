class Ball{

    constructor(x,y,s){
        this.x=x;
        this.y=y;
        this.speed=s;
        this.r=14;
        this.left=true;
        this.up=true;
    }

    display(){
        fill(255, 0, 0)
        ellipse(this.x,this.y,this.r)


    }

    hit (slider) {
        if (this.x >= slider.x && this.x <= slider.x + slider.w) {
            if (this.y >= slider.y - this.r / 2)
                return true;
        }
        return false;
    }

    update(){
      if(this.up){
          this.y -=this.speed;
          if(this.y <=0)
            this.up=false;
          if(this.left){
              this.x -=this.speed;
              if(this.x <=0)
                this.left=false;

          } else{
              this.x +=this.speed;
              if(this.x >=width){
                  this.left=true;
              }
          }

      } else {//down
        this.y +=this.speed;
        if(this.y >=height)
            return true;
            if(this.left){
                this.x -=this.speed;
                if(this.x <=0)
                  this.left=false;
  
            } else{
                this.x +=this.speed;
                if(this.x >=width){
                    this.left=true;
                }
            }
      }
      return false;

    }


}